function projetos(section) {
  section.innerHTML = `<header>
      <h2>Faculdade</h2>
    </header>
    <div class="content">
      <div class="cards">
        <div class="card">
          <h3>Desenvolvimento Web</h3>
          <div class="img-wrapper">
            <div class="buttons">
              <a href="https://universidadedevassouras.edu.br/graduacoes/engenharia-de-software/" target="_blank" title="Ver Projeto">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  viewBox="0 0 24 24"
                  width="24"
                  height="24"
                >
                  <path fill="none" d="M0 0h24v24H0z" />
                  <path
                    d="M12 3c5.392 0 9.878 3.88 10.819 9-.94 5.12-5.427 9-10.819 9-5.392 0-9.878-3.88-10.819-9C2.121 6.88 6.608 3 12 3zm0 16a9.005 9.005 0 0 0 8.777-7 9.005 9.005 0 0 0-17.554 0A9.005 9.005 0 0 0 12 19zm0-2.5a4.5 4.5 0 1 1 0-9 4.5 4.5 0 0 1 0 9zm0-2a2.5 2.5 0 1 0 0-5 2.5 2.5 0 0 0 0 5z"
                  />
                </svg>
              </a>
            </div>
          </div>
          <p>
            Andre Saraiva.
          </p>
          <p>HTML - CSS - JS </p>
        </div>
        <div class="card">
          <h3>Algoritimos</h3>
          <div class="img-wrapper">
            <div class="buttons">
                </svg>
              </a>
              <a href="#projects" id="desafio" title="Ver Projetos">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  viewBox="0 0 24 24"
                  width="24"
                  height="24"
                >
                  <path fill="none" d="M0 0h24v24H0z" />
                  <path
                    d="M12 3c5.392 0 9.878 3.88 10.819 9-.94 5.12-5.427 9-10.819 9-5.392 0-9.878-3.88-10.819-9C2.121 6.88 6.608 3 12 3zm0 16a9.005 9.005 0 0 0 8.777-7 9.005 9.005 0 0 0-17.554 0A9.005 9.005 0 0 0 12 19zm0-2.5a4.5 4.5 0 1 1 0-9 4.5 4.5 0 0 1 0 9zm0-2a2.5 2.5 0 1 0 0-5 2.5 2.5 0 0 0 0 5z"
                  />
                </svg>
              </a>
            </div>
          </div>
          <p>
            Gioliano.
          </p>
          <p>Python</p>
        </div>
        <div class="card">
          <h3>Requisitos</h3>
          <div class="img-wrapper">
            <div class="buttons">
              <a href="https://universidadedevassouras.edu.br/graduacoes/engenharia-de-software/" target="_blank" title="Ver Projeto">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  viewBox="0 0 24 24"
                  width="24"
                  height="24"
                >
                  <path fill="none" d="M0 0h24v24H0z" />
                  <path
                    d="M12 3c5.392 0 9.878 3.88 10.819 9-.94 5.12-5.427 9-10.819 9-5.392 0-9.878-3.88-10.819-9C2.121 6.88 6.608 3 12 3zm0 16a9.005 9.005 0 0 0 8.777-7 9.005 9.005 0 0 0-17.554 0A9.005 9.005 0 0 0 12 19zm0-2.5a4.5 4.5 0 1 1 0-9 4.5 4.5 0 0 1 0 9zm0-2a2.5 2.5 0 1 0 0-5 2.5 2.5 0 0 0 0 5z"
                  />
                </svg>
              </a>
            </div>
          </div>
          <p>Gioliano.</p>
          <p>---</p>
        </div>
        <div class="card">
          <h3>Etica</h3>
          <div class="img-wrapper">
            <div class="buttons">
              <a href="https://universidadedevassouras.edu.br/graduacoes/engenharia-de-software/" target="_blank" title="Ver Projeto">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  viewBox="0 0 24 24"
                  width="24"
                  height="24"
                >
                  <path fill="none" d="M0 0h24v24H0z" />
                  <path
                    d="M12 3c5.392 0 9.878 3.88 10.819 9-.94 5.12-5.427 9-10.819 9-5.392 0-9.878-3.88-10.819-9C2.121 6.88 6.608 3 12 3zm0 16a9.005 9.005 0 0 0 8.777-7 9.005 9.005 0 0 0-17.554 0A9.005 9.005 0 0 0 12 19zm0-2.5a4.5 4.5 0 1 1 0-9 4.5 4.5 0 0 1 0 9zm0-2a2.5 2.5 0 1 0 0-5 2.5 2.5 0 0 0 0 5z"
                  />
                </svg>
              </a>
            </div>
          </div>
          <p>João Coelho.</p>
          <p>---</p>
        </div>
        <div class="card">
          <h3>Praticas extencionistas</h3>
          <div class="img-wrapper">
            <div class="buttons">
              <a href="https://universidadedevassouras.edu.br/graduacoes/engenharia-de-software/" target="_blank" title="Ver Projeto">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  viewBox="0 0 24 24"
                  width="24"
                  height="24"
                >
                  <path fill="none" d="M0 0h24v24H0z" />
                  <path
                    d="M12 3c5.392 0 9.878 3.88 10.819 9-.94 5.12-5.427 9-10.819 9-5.392 0-9.878-3.88-10.819-9C2.121 6.88 6.608 3 12 3zm0 16a9.005 9.005 0 0 0 8.777-7 9.005 9.005 0 0 0-17.554 0A9.005 9.005 0 0 0 12 19zm0-2.5a4.5 4.5 0 1 1 0-9 4.5 4.5 0 0 1 0 9zm0-2a2.5 2.5 0 1 0 0-5 2.5 2.5 0 0 0 0 5z"
                  />
                </svg>
              </a>
            </div>
          </div>
          <p>João Coelho.</p>
          <p>---</p>
        </div>
        <div class="card">
          <h3>Gestão Empresarial</h3>
          <div class="img-wrapper">
            <div class="buttons">
              <a href="https://universidadedevassouras.edu.br/graduacoes/engenharia-de-software/" target="_blank" title="Ver Projeto">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  viewBox="0 0 24 24"
                  width="24"
                  height="24"
                >
                  <path fill="none" d="M0 0h24v24H0z" />
                  <path
                    d="M12 3c5.392 0 9.878 3.88 10.819 9-.94 5.12-5.427 9-10.819 9-5.392 0-9.878-3.88-10.819-9C2.121 6.88 6.608 3 12 3zm0 16a9.005 9.005 0 0 0 8.777-7 9.005 9.005 0 0 0-17.554 0A9.005 9.005 0 0 0 12 19zm0-2.5a4.5 4.5 0 1 1 0-9 4.5 4.5 0 0 1 0 9zm0-2a2.5 2.5 0 1 0 0-5 2.5 2.5 0 0 0 0 5z"
                  />
                </svg>
              </a>
            </div>
          </div>
          <p>
            Douglas
          </p>
          <p>---</p>
        </div>
        <div></div>
        <div class="card">
          <h3>Prática de Leitura</h3>
      
          <p>
            Luciano
          </p>
          <p>---</p>
          <div class="img-wrapper">
          <div class="buttons">
            <a href="https://universidadedevassouras.edu.br/graduacoes/engenharia-de-software/" target="_blank" title="Ver Projeto">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                viewBox="0 0 24 24"
                width="24"
                height="24"
              >
                <path fill="none" d="M0 0h24v24H0z" />
                <path
                  d="M12 3c5.392 0 9.878 3.88 10.819 9-.94 5.12-5.427 9-10.819 9-5.392 0-9.878-3.88-10.819-9C2.121 6.88 6.608 3 12 3zm0 16a9.005 9.005 0 0 0 8.777-7 9.005 9.005 0 0 0-17.554 0A9.005 9.005 0 0 0 12 19zm0-2.5a4.5 4.5 0 1 1 0-9 4.5 4.5 0 0 1 0 9zm0-2a2.5 2.5 0 1 0 0-5 2.5 2.5 0 0 0 0 5z"
                />
              </svg>
            </a>
          </div>
        </div>
        </div>
        <div></div>
      </div>
    </div>`
}

export { projetos };
